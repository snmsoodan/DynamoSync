exports.handler = (event,context,callback) => {

    const a = 'My first lambda function'
    console.log(a);
}